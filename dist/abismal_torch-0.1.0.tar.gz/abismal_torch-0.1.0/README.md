# Abismal_Torch
Testing PyTorch implementation of [absimal](https://github.com/rs-station/abismal/tree/serialization)

![Build](https://github.com/rs-station/reciprocalspaceship/workflows/Build/badge.svg)
[![codecov](https://codecov.io/github/DorisMai/test_abismal_torch/graph/badge.svg?token=VS8SANGY1B)](https://codecov.io/github/DorisMai/test_abismal_torch)
